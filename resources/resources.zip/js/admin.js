$(document).ready(function(){
  $('#chat-container').load("http://localhost/mafija2/resources/views/chat.html");
});
